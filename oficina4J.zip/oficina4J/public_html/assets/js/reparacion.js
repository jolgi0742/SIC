
var jsonMontos = [];
var idRecomendacion = 0;
var idEditarReparacion = 0;

$(document).ready(function() {
    
    ListarReparaciones(0);

    $('#btnBuscar').click(function(){
       var index = document.getElementById('selFiltro').selectedIndex;
       ListarReparaciones(index);
    });

    $("#inpBuscarLista").keyup(function(event) {
        if (event.keyCode === 13 || $('#btnBuscar').val() == '') {
            $('#btnBuscar').click();
        }
    });

    $('#selFiltro').change(function (e) {
        var index = document.getElementById('selFiltro').selectedIndex;
        ListarReparaciones(index);
    });

    $('#btnAgregarReparacion').click(function (e) {

         idEditarReparacion = 0;
         jsonMontos = [];
         Back('step2');
         
        document.getElementById('inpBuscarCliente').value = '';

        document.getElementById('inpFecha').value = '';
        document.getElementById('inpNombre').value = '';
        document.getElementById('inpApellidos').value = '';
        document.getElementById('inpCedula').value = '';
        document.getElementById('inpTelefono').value = '';
        document.getElementById('inpCorreo').value = '';

        document.getElementById('pEstado').value = '';
        document.getElementById('selTrabajo').value = '';
        document.getElementById('inpProducto').value = '';
        document.getElementById('inpModelo').value = '';
        document.getElementById('inpAgente').value = '';
        document.getElementById('inpSerie').value = '';
        document.getElementById('txtDetalleTrabajo').value = '';

         document.getElementById('btnCrearReparacion').innerText = 'Crear reparación';

         document.getElementById('frmReparacion').style.display = 'block';
         document.getElementById('frmReparacionfooter').style.display = 'block';

         $('#reparacionModal').modal('show');
    });

    $("#inpBuscarCliente").keyup(function(event) {
        if (event.keyCode === 13) {
            Buscar();
        }
    });

    $("#inpDetalle, #inpPrecio, #inpCant").keyup(function(event) {
        if (event.keyCode === 13) {

            var detalle = document.getElementById('inpDetalle').value;
            var precio = document.getElementById('inpPrecio').value;
            var cantidad = document.getElementById('inpCant').value;

            if (detalle != '' &&
                precio > 0 &&
                cantidad > 0) 
            {$('#btnAgregarMonto').click();}
            
        }
    });

    $('#btnBuscarCliente, #btnBuscarCliente2').click(function (e) {
        Buscar();
    });

    $('#btnInfoPersonal').click(function (e) {

        var cedula = document.getElementById('inpCedula').value;
        var nombre = document.getElementById('inpNombre').value;
        var apellidos = document.getElementById('inpApellidos').value;
        var telefono = document.getElementById('inpTelefono').value;
        var correo = document.getElementById('inpCorreo').value;

        if (cedula != '' &&
            nombre != '' &&
            apellidos != '' &&
            telefono != '' &&
            correo != '') {

            if (idEditarReparacion==0) 
            {
                var date = new Date();
                date.setDate(date.getDate() + 8);
                var dateString = moment(date).format('YYYY-MM-DD');
                document.getElementById('inpFecha').value = dateString;
            }

            document.getElementById('step2').style.display = 'none';
            document.getElementById('step3').style.display = 'block';
        }else{
            ErrorMessage('¡ Error !','Debe ingresar todos los datos solicitados');
        }

    });

    $('#btnTrabajo').click(function (e) {

        var detalle = document.getElementById('txtDetalleTrabajo').value;
        var trabajo = document.getElementById('selTrabajo').value;
        var producto = document.getElementById('inpProducto').value;
        var modelo = document.getElementById('inpModelo').value;
        var agente = document.getElementById('inpAgente').value;
        var serie = document.getElementById('inpSerie').value;
        var fecha = document.getElementById('inpFecha').value;

        var AccesoFecha = true;

        if (idEditarReparacion > 0) 
        {
            if (fecha == '') {AccesoFecha = false;}
        }

        if (detalle != '' &&
            trabajo != '0' &&
            producto != '' &&
            AccesoFecha) {
            document.getElementById('step3').style.display = 'none';
            document.getElementById('step4').style.display = 'block';
        }else{
            ErrorMessage('¡ Error !','Debe ingresar todos los datos solicitados');
        }

    });

    $('#btnCerrarCliente').click(function (e) {

         document.getElementById('frmReparacion').style.display = 'block';
         document.getElementById('frmReparacionfooter').style.display = 'block';
    });

    $('#btnAgregarMonto').click(function (e) {

        let monto = {
            "detalle": document.getElementById('inpDetalle').value,
            "monto": document.getElementById('inpPrecio').value,
            "cantidad": document.getElementById('inpCant').value
        }

        jsonMontos.push(monto);

        document.getElementById('inpDetalle').value = '';
        document.getElementById('inpPrecio').value = '';
        document.getElementById('inpCant').value = '';

        ListarMontos();
    });

    $('#btnCrearReparacion').click(function (e) {

        document.getElementById('divloadercierre').style.display = 'block';
        document.getElementById('step4').style.display = 'none';

        var cedula = document.getElementById('inpCedula').value;
        var nombre = document.getElementById('inpNombre').value;
        var apellidos = document.getElementById('inpApellidos').value;
        var telefono = document.getElementById('inpTelefono').value;
        var correo = document.getElementById('inpCorreo').value;

        var detalle = document.getElementById('txtDetalleTrabajo').value;
        var trabajo = document.getElementById('selTrabajo').value;
        var producto = document.getElementById('inpProducto').value;
        var modelo = document.getElementById('inpModelo').value;
        var agente = document.getElementById('inpAgente').value;
        var serie = document.getElementById('inpSerie').value;
        var fecha = document.getElementById('inpFecha').value;

        var AccesoMonto = true;

        if (idEditarReparacion > 0) 
        {
            if (jsonMontos.length == 0) {AccesoMonto = false;}
        }

        if (AccesoMonto) 
        {
            $.ajax({
               type:"POST",
               url: dirRoot + 'Reparacion/AgregarReparacion',
               data: {idEditar:idEditarReparacion,
                      cedula:cedula,
                      nombre:nombre,
                      apellidos:apellidos,
                      telefono:telefono,
                      correo:correo,
                      detalle:detalle,
                      trabajo:trabajo,
                      producto:producto,
                      modelo:modelo,
                      agente:agente,
                      serie:serie,
                      fecha:fecha,
                      json:JSON.stringify(jsonMontos)},
               success: function(data) {
                  if(JSON.parse(data).status == 1)
                  { 
                     document.getElementById('divloadercierre').style.display = 'none';
                     document.getElementById('step4').style.display = 'block';
                     jsonMontos = [];
                     Back('step2');
                     document.getElementById("frmReparacion").reset();
                     $('#reparacionModal').modal('hide');
                     var index = document.getElementById('selFiltro').selectedIndex;
                    ListarReparaciones(index);
                  }else{
                     document.getElementById('divloadercierre').style.display = 'none';
                     document.getElementById('step4').style.display = 'block';
                  }
               }
            });
        }else{
            document.getElementById('divloadercierre').style.display = 'none';
            document.getElementById('step4').style.display = 'block';
            ErrorMessage('¡ Error !','Por favor agregue un monto a la reparación');
        }
    });

    $('#btnFinalizarReparacion').click(function (e) {

        if (document.getElementById('txtRecomendaciones').value != '') 
        {
            AplicarCambioEstado(idRecomendacion, document.getElementById('txtRecomendaciones').value);
            $('#recomendacionModal').modal('hide');
            ListarMontos();
        }else{
            ErrorMessage('Falta información','Por favor ingrese las recomendaciones para el cliente');
        }
        
    });

});

function ListarReparaciones(Estado){

    document.getElementById('divloader').style.display = 'block';
    document.getElementById('tbodyReparacion').innerHTML = '';

    var buscar = ReplaceText(document.getElementById('inpBuscarLista').value);

    $.ajax({
       type:"POST",
       url: dirRoot + 'Reparacion/Listar',
       data: {Estado:Estado,},
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             var ObjJson = JSON.parse(data).data;
             var html = '';

             for (const n of ObjJson) {
                var Mostrar = true;
                if (buscar != '') 
                {
                    if (ReplaceText(n['Nombre']).includes(buscar) == false &&
                        ReplaceText(n['Apellidos']).includes(buscar) == false &&
                        ReplaceText(n['Telefono']).includes(buscar) == false &&
                        ReplaceText(n['Trabajo']).includes(buscar) == false
                            ) 
                        {Mostrar = false;}
                }
                if (Mostrar) 
                    {html += getHTMLLista(n['IdReparacion'],n['Fecha'],n['Nombre'] +' ' + n['Apellidos'],n['Telefono'],n['Trabajo'],n['Dias'],n['IdEstado'],n['Monto']);}
             }

             document.getElementById('divloader').style.display = 'none';
             document.getElementById('tbodyReparacion').innerHTML = html;

          }else{

          }
       }
    });

}

function getHTMLLista(id,fecha,nombre,telefono,trabajo,dias,idestado,monto){

    var html = '';

    html += '<tr>';
    html += '<td>'+id+'</td>';
    html += '<td style="min-width: 140px">'+fecha+'</td>';
    html += '<td>'+nombre+'</td>';
    html += '<td>'+telefono+'</td>';
    html += '<td>'+trabajo+'</td>';
    html += '<td>';
    html += '<center>';

    if (idestado < 5) 
    {
        if (dias > 3) {html += '<label class="badge badge-success">'+dias+' dias</label>';}
        if (dias <= 3 && dias > 0) {html += '<label class="badge badge-warning">'+dias+' dias</label>';}
        if (dias <= -200) {html += '<label class="badge badge-secondary">-- dias</label>';}
        else if (dias <= 0) {html += '<label class="badge badge-danger">'+dias+' dias</label>';}
    }else{

    }

    html += '</center>';
    html += '</td>';
    html += '<td style="min-width: 180px">';

    if (idestado == 1) 
    {
        if (monto > 0) 
        {
            html += '<a class="btn btn-secondary btn-icon-split" style="cursor: pointer;" onclick="CambiarEstado('+id+','+idestado+')">';
            html += '<span class="icon text-white-50">';
            html += '<i class="fas fa-fw fa-credit-card"></i>';
            html += '</span>';
            html += '<span class="text">Cotizado</span>';
            html += '</a>';
        }else{
            html += '<a id="btnAdd'+id+'"  class="btn btn-light btn-icon-split" style="cursor: pointer;" onclick="Editar('+id+',true)">';
            html += '<span class="text">Agregar cobro</span>';
            html += '</a>';
        }
    }
    else if (idestado == 2) 
    {
        html += '<a class="btn btn-warning btn-icon-split" style="cursor: pointer;" onclick="CambiarEstado('+id+','+idestado+')">';
        html += '<span class="icon text-white-50">';
        html += '<i class="fas fa-fw fa-wrench"></i>';
        html += '</span>';
        html += '<span class="text">En revisión</span>';
        html += '</a>';
    }
    else if (idestado == 3) 
    {
        html += '<a class="btn btn-info btn-icon-split" style="cursor: pointer;" onclick="CambiarEstado('+id+','+idestado+')">';
        html += '<span class="icon text-white-50">';
        html += '<i class="fas fa-fw fa-thumbs-up"></i>';
        html += '</span>';
        html += '<span class="text">Terminado</span>';
        html += '</a>';
    }
    else if (idestado == 4) 
    {
        html += '<a class="btn btn-success btn-icon-split" style="cursor: pointer;" onclick="CambiarEstado('+id+','+idestado+')">';
        html += '<span class="icon text-white-50">';
        html += '<i class="fas fa-fw fa-check"></i>';
        html += '</span>';
        html += '<span class="text">Entregado</span>';
        html += '</a>';
    }
    else if (idestado == 5) 
    {
        html += '<center>';
        html += '<label class="badge badge-success"><i class="fas fa-check"></i> Entregado</label>';
        html += '</center>';
    }
    else if (idestado == 6) 
    {
        html += '<a class="btn btn-light btn-icon-split" style="cursor: pointer;" onclick="Activacion('+id+')">';
        html += '<span class="icon text-white-50">';
        html += '<i class="fas fa-fw fa-check"></i>';
        html += '</span>';
        html += '<span class="text">Reactivar</span>';
        html += '</a>';
    }

    html += '</td>';
    html += '<td>';
    html += '<center><img id="img'+id+'" src="'+dirRoot+'/public_html/assets/img/ajax-loader.gif?t=<?=time()?>" alt="About Hero" style="width: 40px; display:none"></center>';
    html += '<div id="btns'+id+'">';
    html += '<center>';
    html += '<a class="btn btn-light btn-circle btn-sm" onclick="ObtenerProcesos('+id+')">';
    html += '<i class="fas fa-info"></i>';
    html += '</a>&nbsp;'
    html += '<a class="btn btn-info btn-circle btn-sm" onclick="Editar('+id+')">';
    html += '<i class="fas fa-pen"></i>';
    html += '</a>&nbsp;';
    html += '<a class="btn btn-secondary btn-circle btn-sm" onclick="ImprimirFactura('+id+')" style="cursor: pointer;">';
    html += '<i class="fas fa-print"></i>';
    html += '</a>&nbsp;';
    html += '<a class="btn btn-danger btn-circle btn-sm" onclick="Activacion('+id+',\'Desactivar\')" style="cursor: pointer;">';
    html += '<i class="fa fa-times"></i>';
    html += ' </a>';
    html += '</center>';
    html += '</div>';
    html += '</td>';
    html += '</tr>';

    return html;
}

function ObtenerProcesos(id){

    $('#procesosModal').modal('show');
    document.getElementById('tbodyDetalleProcesos').innerHTML = '';
    document.getElementById('divloaderprocesos').style.display = 'block';

    $.ajax({
       type:"POST",
       url: dirRoot + 'Reparacion/Procesos',
       data: {id:id},
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             var html = "";
             for (const n of JSON.parse(data).data) {
                 html += "<tr>";
                 html += "<th>"+n['Nombre']+"</th>";
                 html += "<th>"+n['Detalle']+"</th>";
                 html += "<th>"+n['Fecha']+"</th>";
                 html += "</tr>";
             }
             document.getElementById('divloaderprocesos').style.display = 'none';
             document.getElementById('tbodyDetalleProcesos').innerHTML = html;
          }
       }
    });
}

function CambiarEstado(id,idEstado){

    if (idEstado == 3) 
    {
        idRecomendacion = id;
        $('#recomendacionModal').modal('show');
    }else{
        AplicarCambioEstado(id, '');
    }
}

function Activacion(id, estado = 'Activar'){
    swal({
    title: estado,
    html: "¿Esta seguro que desea "+ estado.toLowerCase() +" este servicio?",
    type: "question",
    showCancelButton: true,
    cancelButtonColor: "#DD6B55",
    confirmButtonColor: "#96C473",
    confirmButtonText: 'Si',
    cancelButtonText: "No",
    reverseButtons: true
    }).then(
    function (isConfirm) 
    {
        if (isConfirm["value"] == true) 
        {
            document.getElementById('divloader').style.display = 'block';
            document.getElementById('tbodyReparacion').innerHTML = '';

            $.ajax({
               type:"POST",
               url: dirRoot + 'Reparacion/Activacion',
               data: {id:id},
               success: function(data) {
                  if(JSON.parse(data).status == 1)
                  {
                     var index = document.getElementById('selFiltro').selectedIndex;
                     ListarReparaciones(index);
                  }
               }
            });
        }
    });
}

function AplicarCambioEstado(id, Recomendaciones){
    swal({
    title: "Cambiar estado",
    html: "Si cambia de estado este no podrá ser retornado a un estado anterior.<br><br> ¿Esta seguro que desea continuar?",
    type: "question",
    showCancelButton: true,
    cancelButtonColor: "#DD6B55",
    confirmButtonColor: "#96C473",
    confirmButtonText: 'Si',
    cancelButtonText: "No",
    reverseButtons: true
    }).then(
    function (isConfirm) 
    {
        if (isConfirm["value"] == true) 
        {
            document.getElementById('divloader').style.display = 'block';
            document.getElementById('tbodyReparacion').innerHTML = '';

            $.ajax({
               type:"POST",
               url: dirRoot + 'Reparacion/CambiarEstado',
               data: {id:id,Recomendaciones:Recomendaciones},
               success: function(data) {
                  if(JSON.parse(data).status == 1)
                  {
                     var index = document.getElementById('selFiltro').selectedIndex;
                     ListarReparaciones(index);
                  }
               }
            });
        }
    });
}

function ListarMontos(){

     var html = '';
     let dollarUSLocale = Intl.NumberFormat('en-US');
     var TotalGen = 0;
     var id = 0;

     for (const n of jsonMontos) {

        var monto = n['monto'];
        var iva = parseInt(n['monto'] * 0.13);
        var total = (n['monto'] * n['cantidad']);

        TotalGen += (total + iva);

        html += '<tr>';
        html += '<td style="padding: 0.2rem;">'+n['detalle']+'</td>';
        html += '<td style="padding: 0.2rem;">₡ '+ dollarUSLocale.format(monto)+'</td>';
        html += '<td style="padding: 0.2rem;">₡ '+ dollarUSLocale.format(iva)+'</td>';
        html += '<td style="padding: 0.2rem;">'+n['cantidad']+'</td>';
        html += '<td style="padding: 0.2rem;">₡ '+dollarUSLocale.format(total + iva)+'</td>';
        html += '<td style="padding: 0.2rem;"><center><a class="btn btn-light btn-circle btn-sm" onclick="Eliminar('+id+')" style="cursor: pointer;">';
        html += '<i class="fas fa-times"></i>';
        html += ' </a></center></td>';
        html += '</tr>';

        id++;
     }

     document.getElementById('hMonto').innerHTML = '₡ ' + dollarUSLocale.format(TotalGen);
     document.getElementById('tbodyDetalle').innerHTML = html;
}

function Eliminar(id){

    var jsonTemp = [];
    var cont = 0;

    for (const n of jsonMontos) {

        if (cont != id) 
        {
            let monto = {
                "detalle": n['detalle'],
                "monto": n['monto'],
                "cantidad": n['cantidad']
            }

            jsonTemp.push(monto);
        }

        cont++;
    }
    
    jsonMontos = jsonTemp;
    ListarMontos();
}

function Buscar(){
    var buscar = document.getElementById('inpBuscarCliente').value;

    document.getElementById('frmBuscar').style.display = 'none';
    document.getElementById('divloaderbuscar').style.display = 'block';

    if (buscar.length == 8 ||
        buscar.length == 9 ||
        buscar.length == 10 ||
        buscar.length == 12) {

        $.ajax({
           type:"POST",
           url: dirRoot + 'Usuarios/BuscarUsuarios',
           data: {Buscar:buscar,},
           success: function(data) {
              if(JSON.parse(data).status == 1)
              {
                 
                 var ObjJson = JSON.parse(data).data[0];

                 document.getElementById('inpCedula').value = ObjJson['Cedula'];
                 document.getElementById('inpNombre').value = ObjJson['Nombre'];
                 document.getElementById('inpApellidos').value = ObjJson['Apellidos'];
                 document.getElementById('inpTelefono').value = ObjJson['Telefono'];
                 document.getElementById('inpCorreo').value = ObjJson['Correo'];

                 document.getElementById('frmBuscar').style.display = 'block';
                 document.getElementById('divloaderbuscar').style.display = 'none';
                 document.getElementById('step1').style.display = 'none';
                 document.getElementById('step2').style.display = 'block';
              }else{
                 document.getElementById('inpCedula').value = '';
                 document.getElementById('inpNombre').value = '';
                 document.getElementById('inpApellidos').value = '';
                 document.getElementById('inpTelefono').value = '';
                 document.getElementById('inpCorreo').value = '';

                 document.getElementById('frmBuscar').style.display = 'block';
                 document.getElementById('divloaderbuscar').style.display = 'none';
                 document.getElementById('step1').style.display = 'none';
                 document.getElementById('step2').style.display = 'block';
              }
           }
        });
        
    }else{
        document.getElementById('frmBuscar').style.display = 'block';
        document.getElementById('divloaderbuscar').style.display = 'none';
        ErrorMessage('¡ Error !','Por favor ingrese una cédula o un número de teléfono válido');
    }
}

function Back(id){
    var Id = id.replace('step','');

    for (var i = 1; i <= 4; i++) {
        document.getElementById('step' + i).style.display = 'none';
    }

    document.getElementById('step' + (Id-1)).style.display = 'block';
}

function Editar(id, btn = false){
    document.getElementById('img'+id).style.display = 'block';
    document.getElementById('btns'+id).style.display = 'none';

    if (btn) { document.getElementById('btnAdd'+id).style.pointerEvents = 'none'; }
    
    $.ajax({
       type:"POST",
       url: dirRoot + 'Reparacion/ConsultarReparacion',
       data: {id:id,},
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
            var jsonObj = JSON.parse(data).data[0];

            idEditarReparacion = jsonObj['IdReparacion'];
            
            document.getElementById('inpBuscarCliente').value = jsonObj['Cedula'];

            document.getElementById('inpFecha').value = jsonObj['Termina'];
            document.getElementById('inpNombre').value = jsonObj['Nombre'];
            document.getElementById('inpApellidos').value = jsonObj['Apellidos'];
            document.getElementById('inpCedula').value = jsonObj['Cedula'];
            document.getElementById('inpTelefono').value = jsonObj['Telefono'];
            document.getElementById('inpCorreo').value = jsonObj['Correo'];

            document.getElementById('pEstado').value = jsonObj['Estado'];
            document.getElementById('selTrabajo').value = jsonObj['Equipo'];
            document.getElementById('inpProducto').value = jsonObj['Marca'];
            document.getElementById('inpModelo').value = jsonObj['Modelo'];
            document.getElementById('inpAgente').value = jsonObj['Motor'];
            document.getElementById('inpSerie').value = jsonObj['Serie'];
            document.getElementById('txtDetalleTrabajo').value = jsonObj['Trabajo'];

            //document.getElementById('pRecomendaciones').innerText = jsonObj['Recomendaciones'];

            var montototal = 0;
            jsonMontos = [];

            for (const n of jsonObj.montos) {

                let monto = {
                    "detalle": n['Detalle'],
                    "monto": n['Monto'],
                    "cantidad": n['Cantidad']
                }

                jsonMontos.push(monto);
            }
            
            ListarMontos();
            Back('step3');

            document.getElementById('btnCrearReparacion').innerText = 'Actualizar';

            document.getElementById('img'+id).style.display = 'none';
            document.getElementById('btns'+id).style.display = 'block';
            if (btn) { document.getElementById('btnAdd'+id).style.pointerEvents = 'auto'; }

            $('#reparacionModal').modal('show');
          }else{
            document.getElementById('img'+id).style.display = 'none';
            document.getElementById('btns'+id).style.display = 'block';
            if (btn) { document.getElementById('btnAdd'+id).style.pointerEvents = 'auto'; }
            ErrorMessage('¡ Error !',JSON.parse(data).msg);
          }
       }
    });
}

function ImprimirFactura(id){

    swal({
    title: "Seleccione una opción",  
    showCancelButton: true,
    cancelButtonColor: "#A4948F",
    confirmButtonColor: "#A4948F",
    confirmButtonText: 'Imprimir factura completa',
    cancelButtonText: "Imprimir ticket de reparación",
    reverseButtons: true
    }).then(
    function (isConfirm) 
    {
        var confirm = isConfirm["value"];
        
        if (confirm) 
        {
            ImprimirFacturaCompleta(id);
        }else{
            ImprimirTicket(id);
        }
    });

}

function ImprimirTicket(id){

    document.getElementById('img'+id).style.display = 'block';
    document.getElementById('btns'+id).style.display = 'none';
    
    $.ajax({
       type:"POST",
       url: dirRoot + 'Reparacion/ConsultarReparacion',
       data: {id:id,},
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
            var jsonObj = JSON.parse(data).data[0];

            document.getElementById('lblIDprint').innerText = jsonObj['IdReparacion'];
            document.getElementById('lblFecha').innerText = jsonObj['Termina'];
            document.getElementById('lblCliente').innerText = jsonObj['Nombre'] + ' ' + jsonObj['Apellidos'];

            document.getElementById('pEstado').innerText = jsonObj['Estado'];
            document.getElementById('lblEquipo').innerText = jsonObj['Marca'] + ' / ' + jsonObj['Modelo'] + ' / ' + jsonObj['Serie'];
            document.getElementById('lblTrabajo').innerText = jsonObj['Trabajo'];

            var html = '';
            var montototal = 0;
            let dollarUSLocale = Intl.NumberFormat('en-US');

            for (const n of jsonObj.montos) {

                var iva = parseInt(n['Cantidad'] * (n['Monto'] * 0.13));
                var total = parseInt(n['Cantidad'] * n['Monto']) + iva;

                html += '<tr>';
                html += '<td style="font-size: 12px;">'+n['Cantidad']+'</td>';
                html += '<td style="font-size: 12px;">'+n['Detalle']+'</td>';
                html += '<td style="font-size: 12px;"><b>'+ dollarUSLocale.format(total)+'</b></td>';
                html += '</tr>';

                montototal = montototal + total;
            }

            html += '<tr>';
            html += '<th><hr></th>';
            html += '<th><hr></th>';
            html += '<th><hr></th>';
            html += '</tr>';
            html += '<tr>';
            html += '<td style="font-size: 12px;">TOTAL</td>';
            html += '<td></td>';
            html += '<td style="font-size: 12px;"><b>'+  dollarUSLocale.format(montototal) +'</b></td>';
            html += '</tr>';

            document.getElementById('tbItems').innerHTML = html;

            var divElementContents = document.getElementById("divImprimirTicket").innerHTML;
            var windows = window.open('', '', 'height=800, width=1200');
            
            document.getElementById('img'+id).style.display = 'none';
            document.getElementById('btns'+id).style.display = 'block';

            windows.document.write('<html>');
            windows.document.write('<body >');
            windows.document.write(divElementContents);
            windows.document.write('</body></html>');
            windows.document.close();
            windows.print();
            windows.close();
            
          }else{
            document.getElementById('img'+id).style.display = 'none';
            document.getElementById('btns'+id).style.display = 'block';
            ErrorMessage('¡ Error !',JSON.parse(data).msg);
          }
       }
    });
}

function ImprimirFacturaCompleta(id){

    document.getElementById('img'+id).style.display = 'block';
    document.getElementById('btns'+id).style.display = 'none';
    
    $.ajax({
       type:"POST",
       url: dirRoot + 'Reparacion/ConsultarReparacion',
       data: {id:id,},
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
            var jsonObj = JSON.parse(data).data[0];

            document.getElementById('bCodigo').innerText = jsonObj['IdReparacion'];
            document.getElementById('pFecha').innerText = jsonObj['Fecha'];
            document.getElementById('pTermina').innerText = jsonObj['Termina'];
            document.getElementById('pCliente').innerText = jsonObj['Nombre'] + ' ' + jsonObj['Apellidos'];
            document.getElementById('pCedula').innerText = jsonObj['Cedula'];
            document.getElementById('pTelefono').innerText = jsonObj['Telefono'];

            document.getElementById("selTrabajo").value = jsonObj['Equipo'];

            var sel = document.getElementById("selTrabajo");
            var text= sel.options[sel.selectedIndex].text;

            document.getElementById('pEstado').innerText = jsonObj['Estado'];
            document.getElementById('pEquipo').innerText = text;
            document.getElementById('pMarca').innerText = jsonObj['Marca'];
            document.getElementById('pModelo').innerText = jsonObj['Modelo'];
            document.getElementById('pMotor').innerText = jsonObj['Motor'];
            document.getElementById('pSerie').innerText = jsonObj['Serie'];
            document.getElementById('pTrabajo').innerText = jsonObj['Trabajo'];

            document.getElementById('pRecomendaciones').innerText = jsonObj['Recomendaciones'];

            var html = '';
            var montototal = 0;
            let dollarUSLocale = Intl.NumberFormat('en-US');

            for (const n of jsonObj.montos) {

                var iva = parseInt(n['Cantidad'] * (n['Monto'] * 0.13));
                var total = parseInt(n['Cantidad'] * n['Monto']) + iva;

                html += '<tr>';
                html += '<td><b>'+n['Cantidad']+'</b></td>';
                html += '<td><b>'+n['Detalle']+'</b></td>';
                html += '<td><b>₡ '+ dollarUSLocale.format(n['Monto'])+'</b></td>';
                html += '<td><b>₡ '+ dollarUSLocale.format(iva)+'</b></td>';
                html += '<td><b>₡ '+ dollarUSLocale.format(total)+'</b></td>';
                html += '</tr>';

                montototal = montototal + total;
            }

            document.getElementById('bTotal').innerText = '₡ '+ dollarUSLocale.format(montototal);
            document.getElementById('tbodyMontosPrint').innerHTML = html;

            var divElementContents = document.getElementById("divImprimir").innerHTML;
            var windows = window.open('', '', 'height=800, width=1200');
            
            document.getElementById('img'+id).style.display = 'none';
            document.getElementById('btns'+id).style.display = 'block';

            windows.document.write('<html>');
            windows.document.write('<body >');
            windows.document.write(divElementContents);
            windows.document.write('</body></html>');
            windows.document.close();
            windows.print();
            windows.close();
            
          }else{
            document.getElementById('img'+id).style.display = 'none';
            document.getElementById('btns'+id).style.display = 'block';
            ErrorMessage('¡ Error !',JSON.parse(data).msg);
          }
       }
    });
}

function ReplaceText(value){
    value = value.toLowerCase();
    value = value.replace("á","a");
    value = value.replace("é","e");
    value = value.replace("í","i");
    value = value.replace("ó","o");
    value = value.replace("ú","u");
    value = value.replace("ë","e");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    return value;
}