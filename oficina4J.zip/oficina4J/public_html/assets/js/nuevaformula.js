
var colorselected = 0;
var marcaselected = 0;
var temprowcolor = null;
var temprowmarca = null;

var IdProyecto = 0;
var IdFormulaGen = 0;

var jsonColores = [];
var jsonProductos = [];

var jsonSecciones = [];
var jsonSeccionesFavoritas = [];
var jsonFormula = [{
                "codcolor": 0,
                "color": "",
                "codproducto": 0,
                "producto": "",
                "peso": 0,
                "Tipo":""
            }];

$(document).ready(function() {

    const urlParams = new URLSearchParams(window.location.search);
    IdProyecto = urlParams.get('id');

    ListarFormulasDB(0);
    ListarFormulasDB(1);
	ListarColores();
	ListarFabricantes();

	$('#selLitros').change(function(){
       ListarFormula();
    });

    $("#inpBuscarLista").keyup(function(event) {
        if (event.keyCode === 13) {
            $('#btnBuscar').click();
        }
    });

	$('#btnAgregarColor').click(function (e) {

        if (document.getElementById('selColor').selectedIndex > 0 ) 
        {
            var index = document.getElementById("selColor").value;

            let formula = {
                "codcolor": jsonColores[index].Codigo,
                "color": jsonColores[index].Color,
                "codproducto": 0,
                "producto": "",
                "peso": 0,
                "Tipo": jsonColores[index].Tipo
            }

            jsonFormula.push(formula);

            document.getElementById('selColor').selectedIndex = 0;

            ListarFormula();
        }else{
            ErrorMessage('Falta información','Por favor seleccione el color y el producto');
        }
    });

    $('#selProducto').change(function (e) {

        if (document.getElementById('selProducto').selectedIndex > 0 ) 
        {
            var index = document.getElementById('selProducto').value;

            jsonFormula[0].codproducto = jsonProductos[index].Codigo;
            jsonFormula[0].producto = jsonProductos[index].Marca;

            document.getElementById('pCodBase').innerText = jsonProductos[index].Codigo;
            document.getElementById('pTipoBase').innerText = jsonProductos[index].Tipo;

            ListarFormula();
        }else{
            ErrorMessage('Falta información','Por favor seleccione el color y el producto');
        }
    });

    $("#SelFormulas").change(function(event) {
        
        if (this.value > 0) 
        {
            document.getElementById('tbodyFormula').innerHTML = '';
            document.getElementById('divloader').style.display = 'block';

            for (const n of jsonSecciones) {
                if (n['IdSeccion'] == this.value) 
                {
                    IdFormulaGen = this.value;
                    document.getElementById('inpDetalle').value = n['Detalle'];
                    document.getElementById('SelSuperficie').value = n['Superficie'];
                    document.getElementById('SelManos').value = n['Manos'];
                    document.getElementById('txtNotas').value = n['Notas'];
                    break;
                }
            }

            document.getElementById('pCodBase').innerText = '';
            document.getElementById('pTipoBase').innerText = '';
            document.getElementById('selProducto').selectedIndex = 0;
            ObtenerJSONFormula(this.value,0);

        }else{
            LimpiarFormula();
        }

    });

    $("#btnFavoritaSelect").click(function(event) {
        
        document.getElementById('tbodyFormula').innerHTML = '';
        document.getElementById('divloader').style.display = 'block';

        for (const n of jsonSeccionesFavoritas) {
            if (n['IdSeccion'] == document.getElementById('SelFormulasFavoritas').value) 
            {
                IdFormulaGen = document.getElementById('SelFormulasFavoritas').value;
                document.getElementById('inpDetalle').value = '';
                document.getElementById('SelSuperficie').value = '';
                document.getElementById('SelManos').value = '';
                document.getElementById('txtNotas').value = '';
                break;
            }
        }

        document.getElementById('pCodBase').innerText = '';
        document.getElementById('pTipoBase').innerText = '';
        document.getElementById('selProducto').selectedIndex = 0;
        ObtenerJSONFormula(document.getElementById('SelFormulasFavoritas').value,1);

        $('#favoritasModal').modal('hide');

    });

    $('#btnAgregarFormula').click(function (e) {

        swal({
        title: "Guardar los cambios",
        html: "Si realiza este proceso los cambios estos se guardaran permanentemente.<br><br> ¿Esta seguro que desea continuar?",
        type: "question",
        showCancelButton: true,
        cancelButtonColor: "#DD6B55",
        confirmButtonColor: "#96C473",
        confirmButtonText: 'Si',
        cancelButtonText: "No",
        reverseButtons: true
        }).then(
        function (isConfirm) 
        {
            if (isConfirm["value"] == true) 
            {
                document.getElementById('divloadergen').style.display = 'block';
                document.getElementById('rowdata').style.display = 'none';

                var referencia = document.getElementById('inpDetalle').value;
                var superficie = document.getElementById('SelSuperficie').value;
                var manos = document.getElementById('SelManos').value;
                var notas = document.getElementById('txtNotas').value;

                if (referencia != '' &&
                    superficie != '' &&
                    manos != '' &&
                    jsonFormula.length > 1) 
                {
                    $.ajax({
                       type:"POST",
                       url: dirRoot + 'Formula/AgregarFormula',
                       data: {IdProyecto:IdProyecto,
                              referencia:referencia,
                              superficie:superficie,
                              manos:manos,
                              notas:notas,
                              idseccion:IdFormulaGen,
                              json:JSON.stringify(jsonFormula)},
                       success: function(data) {
                          if(JSON.parse(data).status == 1)
                          { 
                             ListarFormulasDB(0,IdFormulaGen);

                             document.getElementById('divloadergen').style.display = 'none';
                             document.getElementById('rowdata').style.display = 'block';

                             SuccessMessage('Éxito','La fórmula se guardó correctamente');

                          }else{
                            document.getElementById('divloadergen').style.display = 'none';
                            document.getElementById('rowdata').style.display = 'block';
                          }
                       }
                    });
                }else{
                    document.getElementById('divloadergen').style.display = 'none';
                    document.getElementById('rowdata').style.display = 'block';
                    ErrorMessage('¡ Error !','Por favor agregue toda la información solicitada para crear su fórmula');
                }
            }
        });

    });


    $('#btnImprimirFormula').click(function (e) {

        if (jsonFormula.length > 1) 
        {
            document.getElementById('lblProyectoprint').innerText = document.getElementById('inpDetalle').value;
            document.getElementById('lblIDprint').innerText = IdFormulaGen;

            var cantidadL = document.getElementById('selLitros').value;

            var html = '';
            var id = 0;
            var base = 1000 * cantidadL;
            var total = base;

            for (const n of jsonFormula) {
                if (id > 0) { total = total - (n['peso'] * cantidadL); }
                id++;
            }

            id = 0;
            var acumulado = base;

            for (const n of jsonFormula) {

                if (id == 0) 
                {
                    html += '<tr>';
                    html += '<td style="font-size: 12px">'+n['codproducto']+'</td>';
                    html += '<td style="font-size: 12px">'+n['Tipo']+'</td>';
                    html += '<td style="font-size: 12px">'+base+'</td>';
                    html += '<td style="font-size: 12px">'+base+'</td>';
                    html += '</tr>';
                }else{
                    total += parseFloat(n['peso'] * cantidadL);

                    html += '<tr>';
                    html += '<td style="font-size: 12px">'+n['codcolor']+'</td>';
                    html += '<td style="font-size: 12px">'+n['Tipo']+'</td>';
                    html += '<td style="font-size: 12px">'+(n['peso'] * cantidadL).toFixed(2)+'</td>';
                    html += '<td style="font-size: 12px">'+total+'</td>';
                    html += '</tr>';
                }

                id++;
            }

            document.getElementById('tbItems').innerHTML = html;

            var divElementContents = document.getElementById("divImprimir").innerHTML;
            var windows = window.open('', '', 'height=800, width=1200');

            windows.document.write('<html>');
            windows.document.write('<body >');
            windows.document.write(divElementContents);
            windows.document.write('</body></html>');
            windows.document.close();
            windows.print();
            windows.close();
        }else{
            ErrorMessage('Error','La formula debe tener minimo 2 colores');
        }
    });

    $('#btnEliminarFormula').click(function (e) {
        
        var indice = document.getElementById('SelFormulas').selectedIndex;

        if (indice > 0) 
        {
            swal({
            title: "Eliminar la fórmula",
            html: "Si realiza este proceso la formula se eliminará permanentemente.<br><br> ¿Esta seguro que desea continuar?",
            type: "question",
            showCancelButton: true,
            cancelButtonColor: "#DD6B55",
            confirmButtonColor: "#96C473",
            confirmButtonText: 'Si',
            cancelButtonText: "No",
            reverseButtons: true
            }).then(
            function (isConfirm) 
            {
                if (isConfirm["value"] == true) 
                {

                    var Id = document.getElementById('SelFormulas').value;

                    $.ajax({
                       type:"POST",
                       url: dirRoot + 'Formula/DesactivarFormula',
                       data: {Id:Id},
                       success: function(data) {
                          if(JSON.parse(data).status == 1)
                          { 
                             ListarFormulasDB(0,IdFormulaGen);

                             document.getElementById('divloadergen').style.display = 'none';
                             document.getElementById('rowdata').style.display = 'block';

                             SuccessMessage('Éxito','La fórmula se eliminó del sistema');
                             LimpiarFormula();

                          }else{
                            document.getElementById('divloadergen').style.display = 'none';
                            document.getElementById('rowdata').style.display = 'block';
                          }
                       }
                    });
                }
            });
        }else{
            ErrorMessage('Seleccione la fórmula','Debe seleccionar alguna fórmula para realizar esta acción');
        }

    });

    $('#btnDescargarFormulas').click(function (e) {
        ListarFormulasDBTotalReporte();
    });

});

function LimpiarFormula(){
    IdFormulaGen = 0;
    jsonFormula = [{
        "codcolor": 0,
        "color": "",
        "codproducto": 0,
        "producto": "",
        "peso": 1000,
        "Tipo":""
    }];
    document.getElementById('inpDetalle').value = '';
    document.getElementById('SelSuperficie').selectedIndex = 0;
    document.getElementById('SelManos').selectedIndex = 0;
    document.getElementById('txtNotas').value = '';
    document.getElementById('pBase').value = 1000;
    ListarFormula();
}

function ListarFormulasDBTotalReporte(){

    document.getElementById('divloaderdescargar').style.display = 'block';
    document.getElementById('divbotones').style.display = 'none';

    $.ajax({
       type:"POST",
       url: dirRoot + 'Formula/Listarformulatotal',
       data:{IdProyecto:IdProyecto},
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             var ObjJson = JSON.parse(data).data;
             var text = '';

             var cantidadL = document.getElementById('selLitros').value;

             for (const n of ObjJson) {
                 var id = 0;
                 var total = 0;
                 var base = 1000;

                 for (const f of n['Formula']) {
                    total += parseFloat(f['peso']);
                    if (id > 0) { base = base - f['peso']; }
                    id++;
                 }

                 id = 0;
                 var acumulado = base;

                 text += n['Detalle'].replace(',','') + ',,,,,,,,,,' + n['Ingreso'] + '\n';
                 var contador = 0;
                 for (const i of n['Formula']) {
                    if (contador == 0) 
                    {
                        text += 'Codigo,Color,Peso,Acumulado,1L,2L,3L,4L,5L,1\'8,1\'16\n';
                        text += i['codproducto'] + ',' + 
                                i['producto'] + ' (' + i['Tipo'] + ')'  + ',' + 
                                base + ',' + 
                                acumulado.toFixed(0) + ',' + 
                                base + ',' + 
                                base * 2 + ',' + 
                                base * 3 + ',' + 
                                base * 4 + ',' + 
                                base * 5 + ',' + 
                                base / 8 + ',' + 
                                base / 16 + ','
                                + '\n';
                    }else{
                        acumulado += parseFloat(i['peso']);
                        text += i['codcolor'] + ',' +
                                i['color'] + ' (' + i['Tipo'] + ')'  + ',' + 
                                i['peso'] + ',' + 
                                acumulado.toFixed(0) + ',' + 
                                i['peso'] + ',' + 
                                i['peso'] * 2 + ',' + 
                                i['peso'] * 3 + ',' + 
                                i['peso'] * 4 + ',' + 
                                i['peso'] * 5 + ',' + 
                                i['peso'] / 8 + ',' + 
                                i['peso'] / 16 + ','
                                + '\n';
                    }
                    contador++;
                 }
                 text += '\n';
             }

             DescargarReporte('Formulas proyecto: ' + IdProyecto, text);

             document.getElementById('divloaderdescargar').style.display = 'none';
             document.getElementById('divbotones').style.display = 'block';
          }
       }
    });
}

function DescargarReporte(filename, text) {
    
    var element = document.createElement('a');
    
    element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
}

function ObtenerJSONFormula(IdSeccion,Favoritas){

    $.ajax({
       type:"POST",
       url: dirRoot + 'Formula/ListarformulaporID',
       data:{IdSeccion:IdSeccion,Favoritas:Favoritas},
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             var ObjJson = JSON.parse(data).data;
             jsonFormula = ObjJson;
             ListarFormula();
          }
       }
    });

}

function ListarFormulasDB(favoritas,id = -1){

    $.ajax({
       type:"POST",
       url: dirRoot + 'Formula/Listarformula',
       data:{IdProyecto:IdProyecto,Favoritas:favoritas},
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             var ObjJson = JSON.parse(data).data;
             var html = '';

             for (const n of ObjJson) {
                var myseccion = 0;
                if (favoritas == 0) {myseccion = n['IdSeccion'];}else{myseccion = n['IdSeccionFavorita'];}
                html += '<option value="'+myseccion+'">'+n['Detalle']+'</option>';
             }

            if (favoritas == 0) 
            {
                jsonSecciones = ObjJson;
                html = '<option value="0" selected> - Nueva fórmula - </option>' + html;
                document.getElementById('SelFormulas').innerHTML = html;
            }else{
                jsonSeccionesFavoritas = ObjJson;
                document.getElementById('SelFormulasFavoritas').innerHTML = html;
            }

            switch (id) {
              case -1:
                document.getElementById('SelFormulas').value = 0;
                break;
              case 0:
                var theSelect = document.getElementById('SelFormulas');
                var lastValue = theSelect.options[theSelect.options.length - 1].value;
                theSelect.value = lastValue;
                break;
              default:
                let element = document.getElementById('SelFormulas');
                element.value = IdFormulaGen;
            }

          }
       }
    });
}

function ListarFormula(){

     var cantidadL = document.getElementById('selLitros').value;

     var html = '';
     var id = 0;
     var total = 0;
     var base = jsonFormula[0]['peso'] * cantidadL;

     for (const n of jsonFormula) {
        total += parseFloat(n['peso'] * cantidadL);
        if (id > 0) { base = base - (n['peso'] * cantidadL); }
        id++;
     }

     id = 0;
     var acumulado = base;

     for (const n of jsonFormula) {
        if (id > 0) 
        {
            html += '<tr>';
            html += '<td style="padding: 0.2rem;">'+n['color']+'</td>';
            html += '<td style="padding: 0.2rem;">'+n['codcolor']+'</td>';
            html += '<td style="padding: 0.2rem;">'+n['Tipo']+'</td>';
            html += '<td style="padding: 0.2rem;">';
            html += '<div class="col" style="padding-top: 7px">';
            html += '<div class="progress progress-sm mr-2">';
            html += '<div id="divPorcentBar" class="progress-bar bg-primary" role="progressbar"';
            html += 'style="width: '+((100/total) * (n['peso'] * cantidadL))+'%" aria-valuenow="50" aria-valuemin="0"';
            html += 'aria-valuemax="100"></div>';
            html += '</div>';
            html += '</div>';
            html += '</td>';
            html += '<td style="padding: 0.2rem; width: 90px;">';
            html += '<input id="inp'+id+'" onchange="RefrescarFormula('+id+',this.value)" type="number" value="'+(n['peso']*cantidadL).toFixed(2)+'" style="width: 90px; border: none;" />';
            html += '</td>';
            acumulado += parseFloat(n['peso'] * cantidadL);
            html += '<td style="padding: 0.2rem;">'+acumulado.toFixed(2) +'</td>';
            html += '<td style="padding: 0.2rem;">';
            html += '<center><a class="btn btn-light btn-circle btn-sm" style="cursor: pointer" onclick="Eliminar('+id+')">';
            html += '<i class="fa fa-trash"></i>';
            html += '</a></center>';
            html += '</td>';
            html += '</tr>';
        }else{
            const textToFind = n['producto'];
            const dd = document.getElementById ('selProducto');

            base = n['peso'] * cantidadL;

            if (dd.selectedIndex == 0) 
            {
                dd.selectedIndex = [...dd.options].findIndex (option => option.text === textToFind);
                
                document.getElementById('pCodBase').innerText = n['codproducto'];
                document.getElementById('pTipoBase').innerText = n['Tipo'];
                document.getElementById('pBase').value = n['peso'];
            }
        }
        id++;
     }

     var procent = parseInt((100 / base) * base);

     document.getElementById('divPorcentBarBase').style.width = procent+'%';
     document.getElementById('pBase').value = base.toFixed(2);
     document.getElementById('pBaseAcum').innerText = base.toFixed(2);

     document.getElementById('tbodyFormula').innerHTML = html;
     document.getElementById('divloader').style.display = 'none';
}

function Eliminar(id){

    swal({
        title: "Eliminar fila de la fórmula",
        html: "¿Esta seguro que desea eliminar esta fila de la fórmula?",
        type: "question",
        showCancelButton: true,
        cancelButtonColor: "#DD6B55",
        confirmButtonColor: "#96C473",
        confirmButtonText: 'Si',
        cancelButtonText: "No",
        reverseButtons: true
        }).then(
        function (isConfirm) 
        {
            if (isConfirm["value"] == true) 
            {
                var ArrayTemp = [];
                var contador = 0;

                for (const n of jsonFormula) {
                    if (contador != id) 
                    {
                        ArrayTemp.push(n);
                    }
                    contador++;
                }

                jsonFormula = ArrayTemp;
                ListarFormula();
            }
        });
}

function RefrescarFormula(id,value){
    jsonFormula[id].peso = value;
    if (id == 0) {ListarFormula(value);}
    else{ListarFormula();}
    document.getElementById('inp'+id).focus();
}

function ListarColores(){

    $.ajax({
       type:"POST",
       url: dirRoot + 'Formula/Listarcolor',
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             jsonColores = JSON.parse(data).data;
             var html = '<option disabled selected>-- Seleccione el color --</option>';

             var Index = 0;

             for (const n of jsonColores) {
                html += '<option value="'+Index+'">'+n['Color']+'</option>';
                Index++;
             }

             document.getElementById('selColor').innerHTML = html;

          }else{

          }
       }
    });
}

function ListarFabricantes(){

    $.ajax({
       type:"POST",
       url: dirRoot + 'Formula/Listarfabricantes',
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             jsonProductos = JSON.parse(data).data;
             var html = '<option disabled selected>-- Seleccione la base --</option>';

             var Index = 0;

             for (const n of jsonProductos) {
                html += '<option value="'+Index+'">'+n['Marca']+'</option>';
                Index++;
             }

             document.getElementById('selProducto').innerHTML = html;

          }else{

          }
       }
    });
}

function ReplaceText(value){
    value = value.toLowerCase();
    value = value.replace("á","a");
    value = value.replace("é","e");
    value = value.replace("í","i");
    value = value.replace("ó","o");
    value = value.replace("ú","u");
    value = value.replace("ë","e");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    return value;
}