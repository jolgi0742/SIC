function Message(title, text) {
	swal({ 
		title: title, 
		html: text
	});
}

function SuccessMessage(title, text) {
  swal({
	  title: title,
	  html: text,
	  type: "success",
	})
}

function WarningMessage(title, text) {
  swal({
	  title: title,
	  html: text,
	  type: "warning",
	})
}

function ErrorMessage(title, text) {
  swal({
	  title: title,
	  html: text,
	  type: "error",
	})
}

function NotifMessage(title, text) {
  Swal({
  position: 'top-end',
  type: 'success',
  title: title,
  html: text,
  showConfirmButton: false,
  timer: 1500
})
}

