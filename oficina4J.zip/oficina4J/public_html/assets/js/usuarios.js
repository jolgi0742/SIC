
var jsonUsuarios = null;
var IdAutorizacion = 0;

$(document).ready(function() {
    
    ListarUsuarios();

    $('#selActivo').change(function (e) {
      ListarUsuarios();
    });

    $('#btnAgregarUsuario').click(function (e) {

      IdAutorizacion = 0;

      document.getElementById('inpNombre').value = '';
      document.getElementById('inpCorreo').value = '';
      document.getElementById('inpTelefono').value = '';
      document.getElementById('inpClave').value = '';
      document.getElementById('inpConfirmar').value = '';
      document.getElementById('selTipo').selectedIndex = 0;

      document.getElementById('selSucursal').selectedIndex = document.getElementById('selSucursalGen').selectedIndex;
      
      document.getElementById('divPass').style.display = 'block';
      document.getElementById('btnCrear').innerText = 'Crear usuario';

      $('#usuarioModal').modal('show');
    });

    $('#btnCrear').click(function (e) {

      var Nombre = document.getElementById('inpNombre').value;
      var Correo = document.getElementById('inpCorreo').value;
      var Telefono = document.getElementById('inpTelefono').value;
      var Tipo = document.getElementById('selTipo').value;
      var Sucursal = document.getElementById('selSucursal').value;
      var Clave = document.getElementById('inpClave').value;
      var Confirmar = document.getElementById('inpConfirmar').value;

      if (Nombre != '' &&
          Correo != '' &&
          Telefono != '' &&
          Tipo != '' &&
          Sucursal != '' &&
          Clave != '' &&
          Confirmar != '') 
      {
         if (Clave == Confirmar) 
         {
            $('#usuarioModal').modal('hide');

            document.getElementById('tbodyUsuarios').innerHTML = '';
            document.getElementById("divloader").style.display = "block";

            $.ajax({
               type:"POST",
               url: dirRoot + 'Usuarios/AgregarUsuarios',
               data: {Nombre:Nombre,
                      Correo:Correo,
                      Telefono:Telefono,
                      Tipo:Tipo,
                      Sucursal:Sucursal,
                      Clave:Clave,
                      IdAutorizacion:IdAutorizacion},
               success: function(data) {
                  if(JSON.parse(data).status == 1)
                  {
                     ListarUsuarios();
                  }else{
                     ErrorMessage('¡ Error de acceso !',JSON.parse(data).msg);
                     ListarUsuarios();
                  }
               }
            });
         }else{
            ErrorMessage('¡ Error !','Las contraseñas ingresadas no coinciden');
         }
      }else{
         ErrorMessage('¡ Error !','Por favor ingrese todos los datos solicitados');
      }

    });

});

function ListarUsuarios(){

   var Activo = document.getElementById('selActivo').value;
   
   document.getElementById('tbodyUsuarios').innerHTML = '';
   document.getElementById("divloader").style.display = "block";

   $.ajax({
        type:"POST",
        url: dirRoot + 'Usuarios/ListarUsuarios',
        data: {'Activo':Activo},
        success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             jsonUsuarios = JSON.parse(data);

             var html = '';

             for (const n of jsonUsuarios.data) {
                html += getHTML(n['IdAutorizacion'], n['Nombre'], n['Correo'], n['Telefono'], n['IdTipousuario'], n['Tipo'], n['Activo']);
             }

             document.getElementById("divloader").style.display = "none";
             document.getElementById('tbodyUsuarios').innerHTML = html;
          }else{
             document.getElementById("divloader").style.display = "none";
             ErrorMessage('¡ Error de acceso !',JSON.parse(data).msg);
          }
        }
    });
}

function getHTML(id, nombre, correo, telefono, IdTipousuario, Tipousuario, Activo){

   var html = '';

   html += '<tr>';
   html += '<td>'+nombre+'</td>';
   html += '<td>'+correo+'</td>';
   html += '<td>'+telefono+'</td>';
   html += '<td>'+Tipousuario+'</td>';
   html += '<td>';
   html += '<center>';

   html += '<div id="lock'+id+'">';

   if (IdTipousuario != 1 || MiIdUsuario == 1 || MiIdUsuario == 2) 
   {
      html += '<a style="cursor: pointer" class="btn btn-info btn-circle btn-sm" onclick="Editar('+id+', \''+nombre+'\', \''+correo+'\', \''+telefono+'\', '+IdTipousuario+')">';
      html += '<i class="fas fa-pen"></i>';
      html += '</a>&nbsp;';
      if (Activo == '1') 
      {
         html += '<a style="cursor: pointer" class="btn btn-danger btn-circle btn-sm" onclick="Activar('+id+', 0)">';
         html += '<i class="fas fa-lock"></i>';
         html += '</a>';
      }else{
         html += '<a style="cursor: pointer" class="btn btn-success btn-circle btn-sm" onclick="Activar('+id+', 1)">';
         html += '<i class="fas fa-unlock"></i>';
         html += '</a>';
      }
   }else{
      html += '<center><p>--</p></center>'
   }

   html += '</div>';

   html += '<img id="img'+id+'" src="' + dirRoot + '/public_html/assets/img/ajax-loader.gif" alt="About Hero" style="width: 35px; display: none" />';

   html += '</center>';
   html += '</td>';
   html += '</tr>';

   return html;
}

function Editar(Id, Nombre, Correo, Telefono, Tipo){

   IdAutorizacion = Id;

   document.getElementById('inpNombre').value = Nombre;
   document.getElementById('inpCorreo').value = Correo;
   document.getElementById('inpTelefono').value = Telefono;
   document.getElementById('inpClave').value = 'clavetemp';
   document.getElementById('inpConfirmar').value = 'clavetemp';
   document.getElementById('selTipo').selectedIndex = Tipo - 1;
   document.getElementById('selSucursal').selectedIndex = document.getElementById('selSucursalGen').selectedIndex;

   document.getElementById('divPass').style.display = 'none';
   document.getElementById('btnCrear').innerText = 'Actualizar';
   
   $('#usuarioModal').modal('show');

}

function Activar(Id, Estado){

   document.getElementById("img" + Id).style.display = "block";
   document.getElementById("lock" + Id).style.display = "none";

   $.ajax({
        type:"POST",
        url: dirRoot + 'Usuarios/ActivarUsuarios',
        data: {'Id':Id,'Estado':Estado},
        success: function(data) {
          if(JSON.parse(data).status == 1)
          {
            document.getElementById("img" + Id).style.display = "none";
            document.getElementById("lock" + Id).style.display = "block";
            ListarUsuarios();
          }else{
             document.getElementById("img" + Id).style.display = "none";
             document.getElementById("lock" + Id).style.display = "block";
             ErrorMessage('¡ Error en solicitud !',JSON.parse(data).msg);
          }
        }
    });
}