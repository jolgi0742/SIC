
var tokenmemo = '';

$(document).ready(function() {

    try{
        RemoveAttr();
        var menu = 'mnu' + window.location.pathname.replace('/oficina4J/','').replace('oficina4J/','') + window.location.hash;
        
        if (menu == 'mnu') { menu = 'mnuHome'; }

        var element = document.getElementById(menu);
        element.setAttribute("class", "nav-item active");
    }catch{
        var menu = 'mnuHome';
        var element = document.getElementById(menu);
        element.setAttribute("class", "nav-item active");
    }
    

    $('[menu]').click(function(){
        RemoveAttr();
        var menu = 'mnu' + this.pathname.replace('/oficina4J/','') + this.hash;
        element = document.getElementById(menu);
        element.setAttribute("class", "nav-item active");
    });

    $('[cerrarsesion]').click(function(){
    
        $.ajax({ 
          url: dirRoot + 'Home/CerrarSesion', 
          type: 'post', 
          dataType: 'text',
          success: function(response){
              if (response != null) 
              {
                  window.location.replace(dirRoot + 'Home');
              }
          }
       });

    });

    $('#selSucursalGen').change(function(){
        Cambiar();
    });

    $('#btnBuscarSucursal').click(function(){
        $('#sucursalesModal').modal('show');
    });

    $('#btnAgregarSucursal').click(function(){

        if (document.getElementById('inpSucursalNueva').value != '') 
        {
            swal({
            title: 'Agregar sucursal',
            html: "¿Esta seguro que desea agregar esta nueva sucursal?",
            type: "question",
            showCancelButton: true,
            cancelButtonColor: "#DD6B55",
            confirmButtonColor: "#96C473",
            confirmButtonText: 'Si',
            cancelButtonText: "No",
            reverseButtons: true
            }).then(
            function (isConfirm) 
            {
                if (isConfirm["value"] == true) 
                {
                    $.ajax({
                       type:"POST",
                       url: dirRoot + 'Panel/AgregarSucursal',
                       data: {Nombre:document.getElementById('inpSucursalNueva').value},
                       success: function(data) {
                          if(JSON.parse(data).status == 1)
                          {
                             window.location.replace(dirRoot + 'Panel');
                          }
                       }
                    });
                }
            });
        }
    });
});

function Cambiar(){

    sel = document.getElementById('selSucursalGen');
    var Id = sel.value;
    var Sucursal = sel.options[sel.selectedIndex].text;

    $.ajax({
        type:"POST",
        url: dirRoot + 'Panel/CambiarPOS',
        data: {'IdPOS':Id,'POS':Sucursal},
        success: function(data) {
          if(data == 'Exito')
          {
            location.reload();
          }
        }
    });
}

function RemoveAttr(){
    // Get the elements to be iterated
    let htmlElements =
        document.getElementsByName("mnuMenu");

    // Use a regular for-loop
    for (let i = 0; i < htmlElements.length; i++) {
        htmlElements[i].setAttribute("class", "nav-item");
    }
}

function ActivarSucursal(id){
    
    document.getElementById('btnActivaSucursal' + id).style.display = 'none';
    document.getElementById('imgActivaSucursal' + id).style.display = 'block';

    $.ajax({
        type: 'post', 
        dataType: 'text',
        url: dirRoot + 'Panel/ActivarSucursal',
        data: {'IdSucursal':id},
        success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             location.reload();
          }
        }
    });

}