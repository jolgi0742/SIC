
$(document).ready(function() {
    
    $("#txtCorreo").focus();

    $('#btnIngLogin').click(function (e) {

       document.getElementById("divloader").style.display = "block";
       document.getElementById("frmData").style.display = "none";
       document.getElementById("btnIngLogin").disabled = true;

       var telefono = $("#txtCorreo").val();
       var clave = $("#txtClave").val();

       var ResultValidar = ValidarDatosLogin($("#txtCorreo").val(), $("#txtClave").val());

       if (ResultValidar == '') 
       {
          ValidarAcceso(telefono, clave);
       }else{
          document.getElementById("btnIngLogin").disabled = false;
          document.getElementById("divloader").style.display = "none";
          document.getElementById("frmData").style.display = "block";

          ErrorMessage('¡ Error de datos !',ResultValidar);
          $("#txtCorreo").focus();
       }

    });

    $('#txtClave').keypress(function(event){
     var keycode = (event.keyCode ? event.keyCode : event.which);
     if(keycode == '13'){
       $('#btnIngLogin').click();  
     }
   });
});

function ValidarAcceso(telefono, clave, recordar){

    $.ajax({
        type:"POST",
        url: dirRoot + 'Home/ValidarAcceso',
        data: {'telefono':telefono,'clave':clave},
        success: function(data) {
          if(data.response)
          {
             window.location.replace(dirRoot + 'Panel');
          }else{
             document.getElementById("divloader").style.display = "none";
             document.getElementById("frmData").style.display = "block";
             document.getElementById("btnIngLogin").disabled = false;

             ErrorMessage('¡ Error de acceso !',data.message);
             $("#txtClave").val("");
             $("#txtCorreo").val("");
             $("#txtCorreo").focus();
          }
        }
    });
}

function ObtenerClave(clave, proceso){
   
   var result = '';

   $.ajax({
        type:"POST",
        url: dirLogin + '/EncriptaClave',
        data: {'clave':clave,
               'proceso':proceso},
        success: function(data) {
          if(data != '')
          {
             result = data;
          }
        }
   });

   return result;
}

function ValidarDatosLogin(telefono, clave){

   var Resp = '';

   if (telefono == '') { Resp = Resp + ' ◉ Debe ingresar el nombre de usuario <br>'; }
   if (clave == '') { Resp = Resp + ' ◉ Debe ingresar la clave de acceso'; }

   return Resp;

}
