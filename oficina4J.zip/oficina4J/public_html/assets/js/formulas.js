
var idRecomendacion = 0;
var idEditarProyecto = 0;

$(document).ready(function() {
    
    ListarProyectos();

    $('#btnBuscar').click(function(){
       ListarProyectos();
    });

    $("#inpBuscarLista").keyup(function(event) {
        if (event.keyCode === 13 || $('#btnBuscar').val() == '') {
            $('#btnBuscar').click();
        }
    });

    $('#btnAgregarFormula').click(function (e) {

         idEditarProyecto = 0;
         jsonMontos = [];
         Back('step2');
         document.getElementById("frmProyecto").reset();
         document.getElementById('btnCrearProyecto').innerText = 'Crear proyecto';

         document.getElementById('frmProyecto').style.display = 'block';
         document.getElementById('frmProyectofooter').style.display = 'block';

         $('#proyectoModal').modal('show');
    });

    $("#inpBuscarCliente").keyup(function(event) {
        if (event.keyCode === 13) {
            Buscar();
        }
    });

    $('#btnBuscarCliente, #btnBuscarCliente2').click(function (e) {
        Buscar();
    });

    $('#btnInfoPersonal').click(function (e) {

        var cedula = document.getElementById('inpCedula').value;
        var nombre = document.getElementById('inpNombre').value;
        var apellidos = document.getElementById('inpApellidos').value;
        var telefono = document.getElementById('inpTelefono').value;
        var correo = document.getElementById('inpCorreo').value;

        if (cedula != '' &&
            nombre != '' &&
            apellidos != '' &&
            telefono != '' &&
            correo != '') {
            document.getElementById('step2').style.display = 'none';
            document.getElementById('step3').style.display = 'block';
        }else{
            ErrorMessage('¡ Error !','Debe ingresar todos los datos solicitados');
        }

    });

    $('#btnCerrarCliente').click(function (e) {

         document.getElementById('frmProyecto').style.display = 'block';
         document.getElementById('frmProyectofooter').style.display = 'block';
    });

    $('#btnCrearProyecto').click(function (e) {

        document.getElementById('divloadercierre').style.display = 'block';
        document.getElementById('step3').style.display = 'none';

        var cedula = document.getElementById('inpCedula').value;
        var nombre = document.getElementById('inpNombre').value;
        var apellidos = document.getElementById('inpApellidos').value;
        var telefono = document.getElementById('inpTelefono').value;
        var correo = document.getElementById('inpCorreo').value;

        var proyecto = document.getElementById('inpProyecto').value;
        var direccion = document.getElementById('txtDireccion').value;

        if (proyecto != '' &&
            direccion != '') 
        {
            $.ajax({
               type:"POST",
               url: dirRoot + 'Formula/AgregarProyecto',
               data: {idEditar:idEditarProyecto,
                      cedula:cedula,
                      nombre:nombre,
                      apellidos:apellidos,
                      telefono:telefono,
                      correo:correo,
                      proyecto:proyecto,
                      direccion:direccion,},
               success: function(data) {
                  if(JSON.parse(data).status == 1)
                  { 
                     document.getElementById('divloadercierre').style.display = 'none';
                     Back('step2');
                     document.getElementById("frmProyecto").reset();
                     $('#proyectoModal').modal('hide');
                    ListarProyectos();
                  }else{
                     document.getElementById('divloadercierre').style.display = 'none';
                     document.getElementById('step3').style.display = 'block';
                  }
               }
            });
        }else{
            ErrorMessage('Falta información','Por favor ingrese todos los campos solicitados');
            document.getElementById('divloadercierre').style.display = 'none';
            document.getElementById('step3').style.display = 'block';
        }

    });

});

function ListarProyectos(){

    document.getElementById('divloader').style.display = 'block';
    document.getElementById('tbodyFormulas').innerHTML = '';

    var buscar = ReplaceText(document.getElementById('inpBuscarLista').value);

    $.ajax({
       type:"POST",
       url: dirRoot + 'Formula/ListarProyectos',
       success: function(data) {
          if(JSON.parse(data).status == 1)
          {
             var ObjJson = JSON.parse(data).data;
             var html = '';

             for (const n of ObjJson) {

                var Mostrar = true;
                if (buscar != '') 
                {
                    if (ReplaceText(n['Nombre']).includes(buscar) == false &&
                        ReplaceText(n['Apellidos']).includes(buscar) == false &&
                        ReplaceText(n['Telefono']).includes(buscar) == false &&
                        ReplaceText(n['Proyecto']).includes(buscar) == false &&
                        ReplaceText(n['Direccion']).includes(buscar) == false
                            ) 
                        {Mostrar = false;}
                }
                if (Mostrar) 
                    {html += getHTMLLista(n['IdProyecto'],n['Fecha'],n['Nombre'] +' ' + n['Apellidos'],n['Telefono'],n['Proyecto'],n['Formulas'],n['Direccion']);}
             }

             document.getElementById('divloader').style.display = 'none';
             document.getElementById('tbodyFormulas').innerHTML = html;

          }
       }
    });

}

function getHTMLLista(id,fecha,nombre,telefono,proyecto,formulas,direccion){

    var html = '';

    html += '<tr>';
    html += '<td>'+id+'</td>';
    html += '<td style="min-width: 140px">'+fecha+'</td>';
    html += '<td>'+nombre+'</td>';
    html += '<td>'+telefono+'</td>';
    html += '<td>'+proyecto+'</td>';
    html += '<td>';
    html += '<center>';

    if (formulas > 0) 
    {
        html += '<label class="badge badge-success" style="font-size: 15px">'+formulas+'</label>';
    }else{
        html += '<label class="badge badge-light" style="font-size: 15px">0</label>';
    }
    html += '</center>';
    html += '</td>';
    html += '<td>'+direccion+'</td>';
    html += '<td>';
    html += '<div>';
    html += '<center>';
    html += '<a class="btn btn-info btn-circle btn-sm" onclick="Editar('+id+',\''+nombre+'\',\''+telefono+'\',\''+proyecto+'\',\''+direccion+'\')">';
    html += '<i class="fas fa-pen"></i>';
    html += '</a>&nbsp;&nbsp;';
    html += '<a class="btn btn-secondary btn-circle btn-sm" href="'+dirRoot+'Formula?id='+id+'&proyecto='+proyecto+'&cliente='+nombre+'">';
    html += '<i class="fas fa-tachometer-alt"></i>';
    html += '</a>';
    html += '</center>';
    html += '</div>';
    html += '</td>';
    html += '</tr>';

    return html;
}

function Buscar(){
    var buscar = document.getElementById('inpBuscarCliente').value;

    document.getElementById('frmBuscar').style.display = 'none';
    document.getElementById('divloaderbuscar').style.display = 'block';

    if (buscar.length == 8 ||
        buscar.length == 9 ||
        buscar.length == 10 ||
        buscar.length == 12) {

        $.ajax({
           type:"POST",
           url: dirRoot + 'Usuarios/BuscarUsuarios',
           data: {Buscar:buscar,},
           success: function(data) {
              if(JSON.parse(data).status == 1)
              {
                 
                 var ObjJson = JSON.parse(data).data[0];

                 document.getElementById('inpCedula').value = ObjJson['Cedula'];
                 document.getElementById('inpNombre').value = ObjJson['Nombre'];
                 document.getElementById('inpApellidos').value = ObjJson['Apellidos'];
                 document.getElementById('inpTelefono').value = ObjJson['Telefono'];
                 document.getElementById('inpCorreo').value = ObjJson['Correo'];

                 document.getElementById('frmBuscar').style.display = 'block';
                 document.getElementById('divloaderbuscar').style.display = 'none';
                 document.getElementById('step1').style.display = 'none';
                 document.getElementById('step2').style.display = 'block';
              }else{
                 document.getElementById('frmBuscar').style.display = 'block';
                 document.getElementById('divloaderbuscar').style.display = 'none';
                 document.getElementById('step1').style.display = 'none';
                 document.getElementById('step2').style.display = 'block';
              }
           }
        });
        
    }else{
        document.getElementById('frmBuscar').style.display = 'block';
        document.getElementById('divloaderbuscar').style.display = 'none';
        ErrorMessage('¡ Error !','Por favor ingrese una cédula o un número de teléfono válido');
    }
}

function Back(id){
    var Id = id.replace('step','');

    for (var i = 1; i <= 3; i++) {
        document.getElementById('step' + i).style.display = 'none';
    }

    document.getElementById('step' + (Id-1)).style.display = 'block';
}

function Editar(id,nombre,telefono,proyecto,direccion){

    idEditarProyecto = id;
    
    document.getElementById('inpBuscarCliente').value = telefono;
    Buscar();

    document.getElementById('inpProyecto').value = proyecto;
    document.getElementById('txtDireccion').value = direccion;

    Back('step2');

    document.getElementById('btnCrearProyecto').innerText = 'Actualizar';

    $('#proyectoModal').modal('show');

}

function ReplaceText(value){
    value = value.toLowerCase();
    value = value.replace("á","a");
    value = value.replace("é","e");
    value = value.replace("í","i");
    value = value.replace("ó","o");
    value = value.replace("ú","u");
    value = value.replace("ë","e");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    value = value.replace(" ","");
    return value;
}