
$(document).ready(function() {

    $.ajax({ 
      url: dirRoot + 'Reparacion/ListarEstatus', 
      type: 'post', 
      dataType: 'text',
      success: function(response){
          if (JSON.parse(response).status == 1) 
          {
              var Obj = JSON.parse(response).data[0];
              let dollarUSLocale = Intl.NumberFormat('en-US');

              document.getElementById('divTotal').innerText = Obj.Total;
              document.getElementById('divMes').innerText = '₡ ' + dollarUSLocale.format(Obj.IngresosMes);
              document.getElementById('divAnual').innerText = '₡ ' + dollarUSLocale.format(Obj.IngresosAnual);

              var Porcentaje = ((100 / Obj.Total) * Obj.Finalizadas).toFixed(2);

              if (Obj.Total == 0) 
              {document.getElementById('divPorcent').innerText = '0%';}
              else
              {document.getElementById('divPorcent').innerText = Porcentaje + '%';}
              
              document.getElementById('divPorcentBar').style.width = Porcentaje + '%';

              document.getElementById('divPendientes').innerText = Obj.Pendientes;
              document.getElementById('divVigente').innerText = Obj.Vigentes;
              document.getElementById('divCercaVencer').innerText = Obj.Advertencia;
              document.getElementById('divVencidas').innerText = Obj.Vencidas;
              document.getElementById('divFormulas').innerText = Obj.Formulas;
          }
      }
    });

});