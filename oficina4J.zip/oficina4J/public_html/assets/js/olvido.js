
var Id = 0;

$(document).ready(function() {

	$('#btnCorreoClave').click(function (e) {

       document.getElementById("divloader").style.display = "block";
       document.getElementById("frmCorreo").style.display = "none";
       document.getElementById("frmCambio").style.display = "none";

       var correo = $("#inpCorreo").val();

       $.ajax({
       type:"POST",
       url: dirRoot + 'Home/CambiarClave',
       data: {correo:correo,},
       success: function(data) {
	          if(JSON.parse(data).status == 1)
	          {
	          	 Id = JSON.parse(data).data[0].IdAutorizacion; 
	             document.getElementById("divloader").style.display = "none";
	       		 document.getElementById("frmCorreo").style.display = "none";
	       		 document.getElementById("frmCambio").style.display = "block";

	          }else{
	          	document.getElementById("divloader").style.display = "none";
	       		document.getElementById("frmCorreo").style.display = "block";
	       		document.getElementById("frmCambio").style.display = "none";
	       		ErrorMessage('Error',JSON.parse(data).msg,2);
	          }
	       }
	    });

    });

    $('#btnReiniciarClave').click(function (e) {

       document.getElementById("divloader").style.display = "block";
       document.getElementById("frmCorreo").style.display = "none";
       document.getElementById("frmCambio").style.display = "none";

       var temp = $("#inpClaveTemp").val();
       var nueva = $("#inpClaveNueva").val();
       var confirmar = $("#inpConfirmar").val();

       if (nueva == confirmar) 
       {
	       $.ajax({
	       type:"POST",
	       url: dirRoot + 'Home/CambiarClaveCode',
	       data: {Id:Id,temp:temp,nueva:nueva},
	       success: function(data) {
		          if(JSON.parse(data).status == 1)
		          {
		             document.getElementById("divloader").style.display = "none";
		       		 document.getElementById("frmCorreo").style.display = "none";
		       		 document.getElementById("frmCambio").style.display = "none";
		       		 document.getElementById("frmExito").style.display = "block";

		          }else{
		          	document.getElementById("divloader").style.display = "none";
		       		document.getElementById("frmCorreo").style.display = "none";
		       		document.getElementById("frmCambio").style.display = "block";
		       		ErrorMessage('Error',JSON.parse(data).msg);
		          }
		       }
		    });
        }else{
        	document.getElementById("divloader").style.display = "none";
       		document.getElementById("frmCorreo").style.display = "none";
       		document.getElementById("frmCambio").style.display = "block";
        	ErrorMessage('Error','Las claves ingresadas no coinciden');
        }

    });

});
