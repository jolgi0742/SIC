<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reparacion extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');

        if($this->session->userdata('codigo4Jadmin') == null ||
           $this->session->userdata('codigo4Jadmin') == '' ||
           $this->session->userdata('codigo4Jadmin') == 0){
            header("Location: ".$this->config->base_url() . 'Home', TRUE, 301);
            exit();
        }
    }

	public function index()
	{
		$this->load->view('includes/header');
        $this->load->view('includes/navbar');
        $this->load->view('/reparacion');
        $this->load->view('includes/footer');
	}

    public function ListarEstatus(){

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->ListarStatus();

        echo $Result;
    }

    public function Listar(){

        $Estado = $this->input->post('Estado');

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->Listar($Estado);

        echo $Result;
    }

    public function CambiarEstado(){

        $id = $this->input->post('id');
        $Recomendaciones = $this->input->post('Recomendaciones');

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->Cambiar($id,$Recomendaciones);

        $array = json_decode($Result, true);

        $this->load->model('emailmodel');

        $mensaje = $this->emailmodel->MensajeCambioEstado($array['data'][0]['IdReparacion'], $array['data'][0]['Nombre'] . ' ' . $array['data'][0]['Apellidos'], $array['data'][0]['Trabajo'], number_format($array['data'][0]['Monto'],0), $array['data'][0]['Estado']);

        $envio = $this->emailmodel->enviarCorreo($array['data'][0]['Correo'], 'Reparacion 4J No. ' . $array['data'][0]['IdReparacion'], $mensaje);

        echo $Result;
    }

    public function Activacion(){

        $id = $this->input->post('id');
        $Recomendaciones = $this->input->post('Recomendaciones');

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->Activar($id);

        echo $Result;
    }

    public function AgregarReparacion(){

        $idEditar = $this->input->post('idEditar');
        $cedula = $this->input->post('cedula');
        $nombre = $this->input->post('nombre');
        $apellidos = $this->input->post('apellidos');
        $telefono = $this->input->post('telefono');
        $correo = $this->input->post('correo');
        $detalle = $this->input->post('detalle');
        $trabajo = $this->input->post('trabajo');
        $producto = $this->input->post('producto');
        $modelo = $this->input->post('modelo');
        $agente = $this->input->post('agente');
        $serie = $this->input->post('serie');
        $fecha = $this->input->post('fecha');
        $json = $this->input->post('json');

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->Agregar(  $idEditar,
                                                    $cedula,
                                                    $nombre,
                                                    $apellidos,
                                                    $telefono,
                                                    $correo,
                                                    $detalle,
                                                    $trabajo,
                                                    $producto,
                                                    $modelo,
                                                    $agente,
                                                    $serie,
                                                    $fecha,
                                                    $json);

        if ($idEditar == 0) {
            $array = json_decode($Result, true);

            $this->load->model('emailmodel');

            $mensaje = $this->emailmodel->MensajeCambioEstado($array['data'][0]['IdReparacion'], $nombre . ' ' . $apellidos, $trabajo, 'No cotizado', 'Nuevo');

            $envio = $this->emailmodel->enviarCorreo($correo, 'Reparacion 4J No. ' . $array['data'][0]['IdReparacion'], $mensaje);

            $mensaje2 = $this->emailmodel->MensajeCambioEstado($array['data'][0]['IdReparacion'], $nombre . ' ' . $apellidos, $trabajo, 'No cotizado', 'Se ha creado la reparacion');

            $envio2 = $this->emailmodel->enviarCorreo($motor, 'Agente de reparacion 4J No. ' . $array['data'][0]['IdReparacion'], $mensaje2);
        }

        echo $Result;
    }

    public function Procesos(){

        $id = $this->input->post('id');

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->Listarprocesos($id);

        echo $Result;
    }

    public function ConsultarReparacion(){

        $id = $this->input->post('id');

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->Consultarporid($id);

        echo $Result;
    }
}
