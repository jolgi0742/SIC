<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Panel extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');

        if($this->session->userdata('codigo4Jadmin') == null ||
           $this->session->userdata('codigo4Jadmin') == '' ||
           $this->session->userdata('codigo4Jadmin') == 0){
            header("Location: ".$this->config->base_url() . 'Home', TRUE, 301);
            exit();
        }

        if($this->session->userdata('idtipo4Jadmin') == '3'){
            header("Location: ".$this->config->base_url() . 'Reparacion', TRUE, 301);
            exit();
        }
    }

	public function index()
	{
		$this->load->view('includes/header');
        $this->load->view('includes/navbar');
        $this->load->view('/main');
        $this->load->view('includes/footer');
	}

    public function CambiarPOS(){

        $IdPOS = $this->input->post('IdPOS');
        $POS = $this->input->post('POS');

        foreach ($this->session->userdata('listasucursales4Jadmin') as $value) {

            if ($IdPOS == $value['IdSucursal']) {
                $this->session->set_userdata('idsucursal4Jadmin',$IdPOS);
                $this->session->set_userdata('sucursal4Jadmin',$POS);
                $this->session->set_userdata('sucursalcedula4Jadmin',$value['Cedula']);
                $this->session->set_userdata('sucursaltelefono4Jadmin',$value['Telefono']);
                $this->session->set_userdata('sucursalemail4Jadmin',$value['Email']);
                $this->session->set_userdata('sucursaldireccion4Jadmin',$value['Direccion']);
            }

        }

        echo 'Exito';
    }

    public function AgregarSucursal(){

        $Nombre = $this->input->post('Nombre');

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->AgregarSucursal($Nombre);

        $array = json_decode($Result, true);
        
        $this->session->set_userdata('listasucursales4Jadmin',$array['data']);

        echo $Result;
    }

    public function ActivarSucursal(){

        $IdSucursal = $this->input->post('IdSucursal');

        $this->load->model('reparacionmodel');
        $Result = $this->reparacionmodel->ActivarSucursal($IdSucursal);

        $array = [];

        foreach ($this->session->userdata('listasucursales4Jadmin') as $value) {
            
            if ($IdSucursal == $value['IdSucursal']) {
                if ($value['Activo'] == 0) 
                { $value['Activo'] = 1;
                }else
                { $value['Activo'] = 0; }
            }
            
            array_push($array,$value);
        }

        $this->session->set_userdata('listasucursales4Jadmin',$array);

        echo $Result;
    }
}
