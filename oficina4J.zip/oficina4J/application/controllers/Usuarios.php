<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuarios extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');

        if($this->session->userdata('codigo4Jadmin') == null ||
           $this->session->userdata('codigo4Jadmin') == '' ||
           $this->session->userdata('codigo4Jadmin') == 0){
            header("Location: ".$this->config->base_url() . 'Home', TRUE, 301);
            exit();
        }
    }

	public function index()
	{
		$this->load->view('includes/header');
        $this->load->view('includes/navbar');
        $this->load->view('/usuarios');
        $this->load->view('includes/footer');
	}

    public function ListarUsuarios(){

        $Activo = $this->input->post('Activo');

        $this->load->model('usuariosmodel');
        $Result = $this->usuariosmodel->Listar($Activo);

        echo $Result;
    }

    public function BuscarUsuarios(){

        $Buscar = $this->input->post('Buscar');

        $this->load->model('usuariosmodel');
        $Result = $this->usuariosmodel->Buscar($Buscar);

        echo $Result;
    }

    public function ActivarUsuarios(){

        $Id = $this->input->post('Id');
        $Estado = $this->input->post('Estado');

        $this->load->model('usuariosmodel');
        $Result = $this->usuariosmodel->Activar($Id,$Estado);

        echo $Result;
    }

    public function AgregarUsuarios(){

        $Nombre = $this->input->post('Nombre');
        $Correo = $this->input->post('Correo');
        $Telefono = $this->input->post('Telefono');
        $Tipo = $this->input->post('Tipo');
        $Sucursal = $this->input->post('Sucursal');
        $Clave = $this->input->post('Clave');
        $IdAutorizacion = $this->input->post('IdAutorizacion');

        $this->load->model('usuariosmodel');
        $Result = $this->usuariosmodel->Agregar($Nombre,
                                                $Correo,
                                                $Telefono,
                                                $Tipo,
                                                $Sucursal,
                                                $Clave,
                                                $IdAutorizacion);

        echo $Result;
    }
}
