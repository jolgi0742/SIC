<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
    }

	public function index()
	{
		$this->load->view('includes/header');
        $this->load->view('/login');
        $this->load->view('includes/footer');
	}

    public function ValidarAcceso(){

        $telefono = $this->input->post('telefono');
        $clave = $this->input->post('clave');

        $this->load->model('loginmodel');

        $Result = $this->loginmodel->ValidarUsuario($telefono, $clave);

        if ($Result['codigo4Jadmin'] != 0) {

            $this->session->set_userdata($Result);
            
            $info['response'] = TRUE;
            $info['message'] = $Result['err4Jadmin'];

        } else {
            $info['response'] = FALSE;
            $info['message'] = $Result['err4Jadmin'];
        }

        header("Content-Type: application/json; charset=UTF-8");
        echo json_encode($info);
    }


    public function CambiarClave(){

        $correo = $this->input->post('correo');

        $this->load->model('loginmodel');
        $Result = $this->loginmodel->Cambiarclave($correo);

        echo $Result;
    }

    public function CambiarClaveCode(){

        $Id = $this->input->post('Id');
        $temp = $this->input->post('temp');
        $nueva = $this->input->post('nueva');

        $this->load->model('loginmodel');
        $Result = $this->loginmodel->Cambiarclavecode($Id,$temp,$nueva);

        echo $Result;
    }

    public function EncriptaClave(){
        $clave = $this->input->post('clave');
        $proceso = $this->input->post('proceso');
        $this->load->model('encriptamodel');

        if ($proceso == 'enc') {
            $Result = $this->encriptamodel->encrypt($clave);
        }else if ($proceso == 'dec') {
            $Result = $this->encriptamodel->decrypt($clave);
        }
        
        echo $Result;
    }

    public function CerrarSesion() {
        
        $this->load->library('session');
        $this->load->helper(array('form', 'url'));
        $this->session->sess_destroy();

        header("Location: ".$this->config->base_url() . 'Home', TRUE, 301);
    }
}
