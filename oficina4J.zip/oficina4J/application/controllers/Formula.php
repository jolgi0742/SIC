<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Formula extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');

        if($this->session->userdata('codigo4Jadmin') == null ||
           $this->session->userdata('codigo4Jadmin') == '' ||
           $this->session->userdata('codigo4Jadmin') == 0){
            header("Location: ".$this->config->base_url() . 'Home', TRUE, 301);
            exit();
        }
    }

	public function index()
	{
        $this->id = $this->input->get('id', TRUE);

		$this->load->view('includes/header');
        $this->load->view('includes/navbar');

        if ($this->id == '') {
            $this->load->view('/formula');
        }else if ($this->id == 0) {
            $this->load->view('/nuevaformula');
        }else if ($this->id > 0) {
            $this->load->view('/nuevaformula');
        }  
        
        $this->load->view('includes/footer');
	}

    public function Listarcolor(){

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->Listarcolores();

        echo $Result;
    }

    public function Listarfabricantes(){

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->Listarfabricantes();

        echo $Result;
    }

    public function ListarProyectos(){

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->Listarproyectos();

        echo $Result;
    }

    public function Listarformulatotal(){

        $IdProyecto = $this->input->post('IdProyecto');

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->ListarformulasTotales($IdProyecto);

        echo $Result;
    }

    public function Listarformula(){

        $IdProyecto = $this->input->post('IdProyecto');
        $Favoritas = $this->input->post('Favoritas');

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->Listarformulas($IdProyecto,$Favoritas);

        echo $Result;
    }

    public function ListarformulaporID(){

        $IdSeccion = $this->input->post('IdSeccion');
        $Favoritas = $this->input->post('Favoritas');

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->ListarformulaporID($IdSeccion,$Favoritas);

        echo $Result;
    }

    public function AgregarProyecto(){

        $idEditar = $this->input->post('idEditar');
        $cedula = $this->input->post('cedula');
        $nombre = $this->input->post('nombre');
        $apellidos = $this->input->post('apellidos');
        $telefono = $this->input->post('telefono');
        $correo = $this->input->post('correo');
        $proyecto = $this->input->post('proyecto');
        $direccion = $this->input->post('direccion');

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->Agregar($idEditar,
                                                $cedula,
                                                $nombre,
                                                $apellidos,
                                                $telefono,
                                                $correo,
                                                $proyecto,
                                                $direccion);

        echo $Result;
    }

    public function AgregarFormula(){

        $IdProyecto = $this->input->post('IdProyecto');
        $referencia = $this->input->post('referencia');
        $superficie = $this->input->post('superficie');
        $manos = $this->input->post('manos');
        $notas = $this->input->post('notas');
        $idseccion = $this->input->post('idseccion');
        $json = $this->input->post('json');

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->AgregarFormula( $IdProyecto,
                                                        $referencia,
                                                        $superficie,
                                                        $manos,
                                                        $notas,
                                                        $idseccion,
                                                        $json);

        echo $Result;
    }

    public function DesactivarFormula(){

        $Id = $this->input->post('Id');

        $this->load->model('formulasmodel');
        $Result = $this->formulasmodel->DesactivarFormulaID($Id);

        echo $Result;
    }
}