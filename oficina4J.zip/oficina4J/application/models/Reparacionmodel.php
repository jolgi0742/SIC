<?php

class Reparacionmodel extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    public function AgregarSucursal($Nombre) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Nombre' => $Nombre);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url .'Login/AgregarSucursal',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;

    }

    public function ActivarSucursal($IdSucursal) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdSucursal' => $IdSucursal);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url .'Login/ActivarSucursal',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function ListarStatus() 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'));

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Reparacion/Listarstatus',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Listar($Estado) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $dtz = new DateTimeZone("America/Costa_Rica");
        $dt = new DateTime("now", $dtz);
        $dtday = ($dt->format('Y-m-d'));

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Fecha' => $dtday,
                       'IdEstado' => $Estado,
                       'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'));

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Reparacion/Listarreparacion',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Cambiar($id,$Recomendaciones) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $dtz = new DateTimeZone("America/Costa_Rica");
        $dt = new DateTime("now", $dtz);
        $dtday = ($dt->format('Y-m-d H:i:s'));

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Fecha' => $dtday,
                       'Recomendaciones' => $Recomendaciones,
                       'IdReparacion' => $id);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Reparacion/CambiarEstado',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Activar($id) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $dtz = new DateTimeZone("America/Costa_Rica");
        $dt = new DateTime("now", $dtz);
        $dtday = ($dt->format('Y-m-d H:i:s'));

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Fecha' => $dtday,
                       'IdReparacion' => $id);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Reparacion/Activacion',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Agregar($idEditar,
                            $cedula,
                            $nombre,
                            $apellidos,
                            $telefono,
                            $correo,
                            $detalle,
                            $trabajo,
                            $producto,
                            $modelo,
                            $agente,
                            $serie,
                            $fecha,
                            $json) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $dtz = new DateTimeZone("America/Costa_Rica");
        $dt = new DateTime("now", $dtz);
        $dtday = ($dt->format('Y-m-d H:i:s'));

        if ($idEditar == 0) {
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Cedula' => $cedula,
                       'Nombre' => $nombre,
                       'Apellidos' => $apellidos,
                       'Telefono' => $telefono,
                       'Correo' => $correo,
                       'Trabajo' => $detalle,
                       'Equipo' => $trabajo,
                       'Marca' => $producto,
                       'Modelo' => $modelo,
                       'Motor' => $agente,
                       'Serie' => $serie,
                       'Fecha' => $dtday,
                       'Termina' => $fecha,
                       'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'),
                       'jsonDesglose' => $json);
        }else{
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdReparacion' => $idEditar,
                       'Cedula' => $cedula,
                       'Nombre' => $nombre,
                       'Apellidos' => $apellidos,
                       'Telefono' => $telefono,
                       'Correo' => $correo,
                       'Trabajo' => $detalle,
                       'Equipo' => $trabajo,
                       'Marca' => $producto,
                       'Modelo' => $modelo,
                       'Motor' => $agente,
                       'Serie' => $serie,
                       'Fecha' => $dtday,
                       'Termina' => $fecha,
                       'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'),
                       'jsonDesglose' => $json);
        }

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url .'Reparacion/Agregarreparacion',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;

    }

    public function Listarprocesos($id) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdReparacion' => $id);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Reparacion/Listarprocesos',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Consultarporid($id) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdReparacion' => $id);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Reparacion/ConsultarReparacion',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

}

