<?php

class Usuariosmodel extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    public function Session() 
    {   
        $Resp = array(
            'codacceso'  => true);

        return $Resp;
    }

    public function Buscar($Buscar) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Buscar' => $Buscar);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Usuarios/Buscarusuario',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Listar($Activo) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = null;

        if ($Activo < 3) {
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                           'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'),
                           'Status' => $Activo);
        }else{
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                           'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'));
        }

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Login/Listarautorizaciones',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Activar($Id,$Estado) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                           'IdAutorizacion' => $Id,
                           'Status' => $Estado);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url .'Login/Cambiarstatus',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;

    }

    public function Agregar($Nombre,
                            $Correo,
                            $Telefono,
                            $Tipo,
                            $Sucursal,
                            $Clave,
                            $IdAutorizacion) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        if ($this->session->userdata('idtipo4Jadmin') != '1') {
            $Tipo = 3;
            $Sucursal = $this->session->userdata('idsucursal4Jadmin');
        }

        $array = null;

        if ($IdAutorizacion == 0) {
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Nombre' => $Nombre,
                       'Correo' => $Correo,
                       'Telefono' => $Telefono,
                       'Clave' => $Clave,
                       'IdTipousuario' => $Tipo,
                       'IdSucursal' => $Sucursal);
        }else{
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Nombre' => $Nombre,
                       'Correo' => $Correo,
                       'Telefono' => $Telefono,
                       'Clave' => $Clave,
                       'IdTipousuario' => $Tipo,
                       'IdSucursal' => $Sucursal,
                       'IdAutorizacion' => $IdAutorizacion);
        }

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url .'Login/Agregarusuario',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;

    }

}

