<?php

class Formulasmodel extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    public function Listarcolores() 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'));

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Formulas/Listarcolores',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Listarfabricantes() 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'));

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Formulas/Listarproductos',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Listarproyectos() 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'));

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Formulas/Listarproyectos',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function ListarformulasTotales($IdProyecto) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdProyecto' => $IdProyecto);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Formulas/Listarformulastotales',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Listarformulas($IdProyecto,$Favoritas) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdProyecto' => $IdProyecto,
                       'Favoritas' => $Favoritas);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Formulas/Listarformulas',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function ListarformulaporID($IdSeccion,$Favoritas) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdSeccion' => $IdSeccion,
                       'Favoritas' => $Favoritas);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Formulas/ListarformulaporID',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function Agregar($idEditar,
                            $cedula,
                            $nombre,
                            $apellidos,
                            $telefono,
                            $correo,
                            $proyecto,
                            $direccion) 
    {   
        $Url = $this->config->item('APIurllocal');

        $curl = curl_init();

        $dtz = new DateTimeZone("America/Costa_Rica");
        $dt = new DateTime("now", $dtz);
        $dtday = ($dt->format('Y-m-d'));

        if ($idEditar == 0) {
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'Cedula' => $cedula,
                       'Nombre' => $nombre,
                       'Apellidos' => $apellidos,
                       'Telefono' => $telefono,
                       'Correo' => $correo,
                       'Proyecto' => $proyecto,
                       'Direccion' => $direccion,
                       'Fecha' => $dtday,
                       'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'));
        }else{
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdProyecto' => $idEditar,
                       'Cedula' => $cedula,
                       'Nombre' => $nombre,
                       'Apellidos' => $apellidos,
                       'Telefono' => $telefono,
                       'Correo' => $correo,
                       'Proyecto' => $proyecto,
                       'Direccion' => $direccion,
                       'Fecha' => $dtday,
                       'IdSucursal' => $this->session->userdata('idsucursal4Jadmin'));
        }

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url .'Formulas/Agregarproyecto',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;

    }

    public function AgregarFormula( $IdProyecto,
                                    $referencia,
                                    $superficie,
                                    $manos,
                                    $notas,
                                    $idseccion,
                                    $json) 
    {   
        $Url = $this->config->item('APIurllocal');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $dtz = new DateTimeZone("America/Costa_Rica");
        $dt = new DateTime("now", $dtz);
        $dtday = ($dt->format('Y-m-d H:i:s'));

        if ($idseccion == 0) {
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdProyecto' => $IdProyecto,
                       'IdSeccion' => 0,
                       'Referencia' => $referencia,
                       'Superficie' => $superficie,
                       'Manos' => $manos,
                       'Notas' => $notas,
                       'Fecha' => $dtday,
                       'jsonFormula' => $json);
        }else{
            $array = array('Token' => $this->session->userdata('token4Jadmin'),
                       'IdProyecto' => $IdProyecto,
                       'IdSeccion' => $idseccion,
                       'Referencia' => $referencia,
                       'Superficie' => $superficie,
                       'Manos' => $manos,
                       'Notas' => $notas,
                       'Fecha' => $dtday,
                       'jsonFormula' => $json);
        }

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url .'Formulas/Agregarformula',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;

    }

    public function DesactivarFormulaID($Id) 
    {   
        $Url = $this->config->item('APIurllocal');
        $this->load->model('encriptamodel');

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url .'Formulas/DesactivarSeccion',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('Token' => $this->session->userdata('token4Jadmin'),
                                      'IdSeccion' => $Id),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }
}

