<?php

class Loginmodel extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    public function Session() 
    {   
        $Resp = array(
            'codacceso'  => true);

        return $Resp;
    }

    public function ValidarUsuario($micorreo, $miclave) 
    {   
        $Url = $this->config->item('APIurllocal');
        $token = $this->config->item('token');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Login/Acceso',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('Token' => $token,'Correo' => $micorreo,'Clave' => $miclave),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        
        $array = json_decode($response, true);

        $Resp = null;

        if ($array["status"] == 1 && 
            isset($array['data'][0])) {

            $data = $array['data'][0];

            $Resp = array(
                'codigo4Jadmin'  => $data['IdAutorizacion'],
                'nombre4Jadmin'  => $data['Nombre'],
                'correo4Jadmin'  => $data['Correo'],
                'idtipo4Jadmin'  => $data['IdTipousuario'],
                'tipo4Jadmin'  => $data['Tipo'],
                'token4Jadmin'  => $data['Autorizacion'],
                'idsucursal4Jadmin'  => $data['IdSucursal'],
                'sucursal4Jadmin'  => $data['Sucursal'],
                'sucursalcedula4Jadmin'  => $data['Cedula'],
                'sucursaltelefono4Jadmin'  => $data['Telefono'],
                'sucursalemail4Jadmin'  => $data['Email'],
                'sucursaldireccion4Jadmin'  => $data['Direccion'],
                'listasucursales4Jadmin'  => $data['Sucursales'],
                'err4Jadmin'  => '');
        }else{
            $Resp = array(
                'codigo4Jadmin'  => 0,
                'nombre4Jadmin'  => '',
                'correo4Jadmin'  => '',
                'token4Jadmin'  => '',
                'idtipo4Jadmin'  => '',
                'tipo4Jadmin'  => '',
                'token4Jadmin'  => '',
                'idsucursal4Jadmin'  => '',
                'sucursal4Jadmin'  => '',
                'sucursalcedula4Jadmin'  => '',
                'sucursaltelefono4Jadmin'  => '',
                'sucursalemail4Jadmin'  => '',
                'sucursaldireccion4Jadmin'  => '',
                'listasucursales4Jadmin'  => '',
                'err4Jadmin'  => $array['msg']);
        }

        return $Resp;
    }

    public function Cambiarclave($correo) 
    {   
        $Url = $this->config->item('APIurllocal');
        $token = $this->config->item('token');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $clavetemp = $this->generateRandomString();

        $array = array('Token' => $token,
                       'Clave' => $clavetemp,
                       'Correo' => $correo);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Login/Cambiarclave',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        $array = json_decode($response, true);

        $Resp = null;

        if ($array["status"] == 1) {
            $this->load->model('emailmodel');

            $mensaje = $this->emailmodel->MensajeCodigoVerificacion($clavetemp);

            $envio = $this->emailmodel->enviarCorreo($correo, 'Clave temporal', $mensaje);
        }

        return $response;

    }

    public function Cambiarclavecode($Id,$temp,$nueva) 
    {   
        $Url = $this->config->item('APIurllocal');
        $token = $this->config->item('token');

        $this->load->model('encriptamodel');

        $curl = curl_init();

        $array = array('Token' => $token,
                       'IdAutorizacion' => $Id,
                       'Clave' => $temp,
                       'Clavenueva' => $nueva);

        curl_setopt_array($curl, array(
          CURLOPT_URL => $Url.'Login/Cambiarclavecode',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $array,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }

    public function generateRandomString($length = 5) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[random_int(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}

